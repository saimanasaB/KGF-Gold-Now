# Currency-Converter
It's a Currency Converter developed using the exchange rate api , Vanilla JavaScript and HTML/CSS. Its has a swap button in order to swap the conversion.

https://pranav589.github.io/Currency-Converter/
